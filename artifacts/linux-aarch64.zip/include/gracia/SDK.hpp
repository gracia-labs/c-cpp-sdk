#pragma once

#include <array>
#include <cmath>
#include <filesystem>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <type_traits>
#include <variant>
#include <vector>

#include "SDK.h"

// These are C++ RAII wrappers over the C API in SDK.h. Each class holds its opaque
// handle in a unique_ptr, and calls the correct gracia_*_destroy function when it
// goes out of scope. Thus you do not free the handle yourself. See SDK.h for the
// full details of each call, the parameter units, and the env-SH and color-grade
// examples.

namespace gracia {

namespace detail {
// This deleter for the unique_ptr calls the C destroy function Fn on a handle. The
// unique_ptr does not call it on NULL, and it makes ownership move-only, thus Fn runs
// one time for the handle.
template<auto Fn>
struct CDeleter {
  template<class P>
  void operator()(P* p) const { Fn(p); }
};

template<class Ptr, auto Fn>
using Handle = std::unique_ptr<std::remove_pointer_t<Ptr>, CDeleter<Fn>>;
}  // namespace detail

// This class holds one recorded draw-call handle. It calls gracia_draw_call_destroy
// when it goes out of scope. execute() replays the handle into the active render
// pass of the caller. A default DrawCall, or a DrawCall that you moved from, does
// nothing.
class DrawCall {
 public:
  DrawCall() = default;
  explicit DrawCall(GraciaDrawCall ptr) : h_(ptr) {}
  GraciaDrawCall get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }
  void execute(GraciaRenderPass renderPass) {
    if (h_) gracia_draw_call_execute(h_.get(), renderPass);
  }

 private:
  detail::Handle<GraciaDrawCall, gracia_draw_call_destroy> h_;
};

// The draw calls of one pass, with up to two views (mono or stereo) stored inline.
// `stereo` is set only when the pass is truly stereo (multiview, or a mode that is
// not multipass). nullopt means mono.
struct PassDrawCalls {
  std::array<DrawCall, 2> views {};
  uint32_t count = 0;
  std::optional<GraciaStereoMode> stereo;

  bool empty() const { return count == 0; }
  uint32_t size() const { return count; }
  DrawCall& operator[](uint32_t i) { return views[i]; }
  const DrawCall& operator[](uint32_t i) const { return views[i]; }
};

namespace detail {
// The PassDrawCalls of one pass of the C API. It takes the ownership of each handle.
inline PassDrawCalls passOf(const GraciaPassDrawCalls& in) {
  PassDrawCalls out;
  out.stereo = (in.viewCount > 1 || in.stereoMode != GRACIA_STEREO_MODE_MULTIPASS)
    ? std::optional(in.stereoMode) : std::nullopt;
  out.count = in.viewCount > 2 ? 2u : in.viewCount;
  for (uint32_t v = 0; v < out.count; v++)
    if (in.views[v]) out.views[v] = DrawCall(in.views[v]);
  return out;
}
}  // namespace detail

// The four passes that SdkSplatsRenderer::render makes. `buffering` is true when a
// video frame was not ready. Then do not present the frame, and do the render again.
// `compiling` is true while the GPU pipelines of the objects compile. This structure
// is the same as GraciaDrawCalls.
struct DrawCalls {
  PassDrawCalls color;
  PassDrawCalls depth;
  PassDrawCalls motion;
  PassDrawCalls mesh;
  bool buffering = false;
  bool compiling = false;
};

class StaticSplats;
class VideoStream;

// A GPU session (gracia_context_create and gracia_context_destroy). Make one session
// for each device. You make every other object from this session, and you must
// destroy them before the session. Use the bool operator to test for success.
class Context {
 public:
  Context(const GraciaContextDescriptor& desc,
          const std::filesystem::path& cacheDir = {})
    : h_(gracia_context_create(&desc, cacheDir.empty() ? nullptr : cacheDir.c_str())) {}

  GraciaContext get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }
  uint64_t gpuAllocatedBytes() const {
    return h_ ? gracia_context_gpu_allocated_bytes(h_.get()) : 0;
  }
  // Puts the listener of the sounds at a camera: the column-major 4x4 camera-to-world
  // that a render takes as a view transform. Call it each frame. See
  // gracia_audio_set_listener in SDK.h.
  void setListener(const float* cameraToWorld) {
    if (h_) gracia_audio_set_listener(h_.get(), cameraToWorld);
  }
  // HOST output only. Mixes the next `frameCount` frames into `frames`. Call it on
  // your audio thread. Returns false for another output. See gracia_audio_read in
  // SDK.h.
  bool readAudio(float* frames, uint32_t frameCount) {
    return h_ && gracia_audio_read(h_.get(), frames, frameCount);
  }

 private:
  detail::Handle<GraciaContext, gracia_context_destroy> h_;
};

// The splats renderer (gracia_splats_renderer_*). It records the draw calls of each
// frame, and the caller replays them into its own attachments.
class SdkSplatsRenderer {
 public:
  // Makes a renderer for a maximum of `maxSplatsCount` visible splats in one frame.
  // Set `vr` to true for two-eye output. A mono renderer cannot render stereo later.
  // Set `legacyPipeline` to true to use the legacy pipeline on all GPUs (see
  // gracia_splats_renderer_create).
  static SdkSplatsRenderer create(
    const Context* ctx,
    uint32_t maxSplatsCount,
    bool vr = false,
    bool legacyPipeline = false
  ) {
    return SdkSplatsRenderer(
      gracia_splats_renderer_create(ctx->get(), maxSplatsCount, vr, legacyPipeline));
  }

  SdkSplatsRenderer() = default;

  GraciaRenderer get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }

  // Apple only. Gives the tile settings for this splats pass. Use them in the
  // MTLRenderPass that executes the draw calls. (gracia_splats_renderer_metal_tile_settings)
  GraciaMetalTileSettings metalTileSettingsValue(
    const GraciaRendererSplatsPass& splatsPass
  ) const {
    if (!h_) return {};
    return gracia_splats_renderer_metal_tile_settings(h_.get(), &splatsPass);
  }

  // Records a frame. `splats` takes a StaticSplats* or a VideoStream* in a variant.
  // `projections` and `viewTransforms` are column-major 4x4 pointers, one for each
  // eye (see SDK.h). Pass nullptr for motionPass or meshPass to skip that pass. The
  // DrawCalls result holds its handles and frees them when it goes out of scope.
  // Check .buffering before you present.
  DrawCalls render(
    std::span<const std::variant<StaticSplats*, VideoStream*>> splats,
    const float* const* projections, const float* const* viewTransforms,
    const float* locomotionTransform,
    uint32_t targetWidth, uint32_t targetHeight,
    bool vr,
    const GraciaRendererSplatsPass& splatsPass,
    const GraciaRendererMotionPass* motionPass,
    const GraciaRendererMeshPass* meshPass,
    GraciaCommandBuffer commandBuffer
  );

  // Turns a named feature of the renderer on or off.
  void setFlag(const char* key, bool value) {
    if (h_) gracia_splats_renderer_set_flag(h_.get(), key, value);
  }
  // Sets a named float parameter of the renderer.
  void setFloat(const char* key, float value) {
    if (h_) gracia_splats_renderer_set_float(h_.get(), key, value);
  }

  // Requests a pick at normalized device coordinates (x and y in [-1, 1]). The next
  // render() finds the result.
  void setPickNDC(float ndcX, float ndcY) {
    if (h_) gracia_splats_renderer_set_pick_ndc(h_.get(), ndcX, ndcY);
  }

  // Returns the result of the last pick: the index of the object that the pick hit
  // (its position in the render() list), or -1 if the pick hit nothing. Writes the
  // depth of the hit into `outDepth` when you supply it.
  int readPickResult(float* outDepth = nullptr) {
    if (!h_) { if (outDepth) *outDepth = 0; return -1; }
    return gracia_splats_renderer_read_pick_result(h_.get(), outDepth);
  }

  // Returns the number of splats that the SDK drew in the last frame, when the
  // visible-count readback is on; returns 0 if it is off.
  uint32_t readVisibleSplatsCount() const {
    return h_ ? gracia_splats_renderer_read_visible_splats_count(h_.get()) : 0;
  }

 private:
  explicit SdkSplatsRenderer(GraciaRenderer p) : h_(p) {}
  detail::Handle<GraciaRenderer, gracia_splats_renderer_destroy> h_;
};

struct DepthResolveDrawCalls {
  PassDrawCalls color;  // rendered like the splats color pass
  PassDrawCalls depth;  // rendered like the splats depth pass
};

// The depth-data resolver (gracia_depth_resolver_*). It projects the RG32F splat
// depth buffer into a device depth value, a color value, or both. One resolver serves
// a multiview or a multilayer depth pass, and a multipass depth pass takes one for each
// eye, as gracia_depth_resolver_render states.
class SdkDepthResolver {
 public:
  static SdkDepthResolver create(const Context* ctx) {
    return SdkDepthResolver(gracia_depth_resolver_create(ctx->get()));
  }

  SdkDepthResolver() = default;

  GraciaDepthResolver get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }

  // Resolves the depth pass, and returns the draw calls in the stereoMode of the
  // depth pass. A GRACIA_*_FORMAT_UNDEFINED value skips that output.
  DepthResolveDrawCalls render(
    std::span<DrawCall* const> depthViews, GraciaStereoMode stereoMode,
    uint32_t width, uint32_t height,
    std::span<const float* const> projections,
    GraciaColorFormat colorFormat, GraciaDepthFormat depthFormat, bool linearizeColor,
    GraciaCommandBuffer commandBuffer
  ) {
    DepthResolveDrawCalls result;
    if (!h_) return result;
    std::array<GraciaDrawCall, 2> views {};
    const uint32_t count = depthViews.size() > 2 ? 2u : uint32_t(depthViews.size());
    for (uint32_t i = 0; i < count; i++) views[i] = depthViews[i] ? depthViews[i]->get() : nullptr;
    auto raw = gracia_depth_resolver_render(
      h_.get(), views.data(), count, stereoMode,
      width, height, projections.data(),
      colorFormat, depthFormat, linearizeColor, commandBuffer);
    result.color = detail::passOf(raw.color);
    result.depth = detail::passOf(raw.depth);
    return result;
  }

 private:
  explicit SdkDepthResolver(GraciaDepthResolver p) : h_(p) {}
  detail::Handle<GraciaDepthResolver, gracia_depth_resolver_destroy> h_;
};

// A static one-frame asset (gracia_static_splats_*). `contentType` must be PLY, GUF,
// or SOG. Check that get() is not nullptr for a successful load.
class StaticSplats {
 public:
  StaticSplats(
    const Context* context, const char* headerData,
    const std::filesystem::path& filePath,
    GraciaContentType contentType
  ) : h_(gracia_static_splats_create(
        context->get(), headerData, filePath.c_str(), contentType)) {}

  GraciaStaticSplats get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }
  uint32_t count() const    { return h_ ? gracia_static_splats_count(h_.get()) : 0; }
  GraciaBBox bbox() const   { return h_ ? gracia_static_splats_bbox(h_.get()) : GraciaBBox {}; }
  // A bounds that ignores distant splats (the 10th to 90th percentile). It is better
  // to frame a camera automatically.
  GraciaBBox adaptiveBBox() const {
    return h_ ? gracia_static_splats_adaptive_bbox(h_.get()) : GraciaBBox {};
  }
  // A column-major 4x4 float[16], from local to world.
  void setTransform(const float* t) { if (h_) gracia_static_splats_set_transform(h_.get(), t); }
  // A 4x4 SH environment probe (16 floats); nullptr turns it off. See set_env_sh in
  // SDK.h for the layout.
  void setEnvSH(const float* sh4x4) { if (h_) gracia_static_splats_set_env_sh(h_.get(), sh4x4); }
  // An HSV grade: hue (a turn), saturation and value (multipliers), and weight (a mix
  // in [0,1]).
  void setColorGrade(float hue, float saturation, float value, float weight) {
    if (h_) gracia_static_splats_set_color_grade(h_.get(), hue, saturation, value, weight);
  }
  // Turns a named feature of the object on or off.
  void setFlag(const char* key, bool value) { if (h_) gracia_static_splats_set_flag(h_.get(), key, value); }
  // The opacity multiplier of the whole object, in [0,1].
  void setVisibility(float v) { if (h_) gracia_static_splats_set_visibility(h_.get(), v); }
  // Crops to a smaller box. The min and max values are normalized on each axis, in
  // [-1,1], against bbox(). `falloff` is the width of the soft edge, in [0,1].
  void setBboxMask(
    float minX, float minY, float minZ,
    float maxX, float maxY, float maxZ, float falloff) {
    if (h_) gracia_static_splats_set_bbox_mask(
      h_.get(), minX, minY, minZ, maxX, maxY, maxZ, falloff);
  }
  void clearBboxMask() {
    if (h_) gracia_static_splats_clear_bbox_mask(h_.get());
  }

 private:
  detail::Handle<GraciaStaticSplats, gracia_static_splats_destroy> h_;
};

// A metadata-only MINT probe (gracia_video_desc_*): bounds, duration, and audio,
// without a GPU decode. It uses less time and memory than a VideoStream when you
// need only the metadata.
class VideoDesc {
 public:
  VideoDesc(const char* head, const std::filesystem::path& path)
    : h_(gracia_video_desc_create(head, path.c_str())) {}

  GraciaVideoDesc get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }
  GraciaBBox bbox() const     { return h_ ? gracia_video_desc_bbox(h_.get()) : GraciaBBox {}; }
  double duration() const     { return h_ ? gracia_video_desc_duration(h_.get()) : 0.0; }
  uint32_t audioSize() const  { return h_ ? gracia_video_desc_audio_size(h_.get()) : 0; }
  // Copies the audio into `buf`. Allocate audioSize() bytes first. Returns false if
  // there is none.
  bool audioRead(char* buf) const { return h_ && gracia_video_desc_audio_read(h_.get(), buf); }

 private:
  detail::Handle<GraciaVideoDesc, gracia_video_desc_destroy> h_;
};

// A MINT or GRV video for playback (gracia_video_stream_*). Move the playhead with
// setTime(). Call ready() before you render. Then draw the video with
// SdkSplatsRenderer::render.
class VideoStream {
 public:
  // From a local file. `mintHead` is an optional split-asset header (nullptr for one
  // file). Set `needMesh` to true to also decode the proxy mesh stream. `head` opens
  // a GRV video that holds a head hash. See gracia_video_stream_create in SDK.h.
  VideoStream(
    const Context* context, const char* mintHead,
    const std::filesystem::path& path, bool needMesh = false,
    std::span<const uint8_t> head = {}
  ) : h_(gracia_video_stream_create(context->get(), mintHead, path.c_str(), needMesh, head.data(), head.size())) {}

  // A MINT video from an https:// URL, with an optional access token. It is a named function, as a constructor of these
  // arguments would take a call of the constructor above with a null `mintHead` and a path as text.
  static VideoStream fromUrl(const Context* context, const char* url, const char* token = nullptr) {
    return VideoStream(gracia_video_stream_create_from_url(context->get(), url, token));
  }

  // A GRV video from an https:// URL; `head` opens one that holds a head hash.
  static VideoStream fromGrvUrl(const Context* context, const char* url, std::span<const uint8_t> head = {}) {
    return VideoStream(gracia_video_stream_create_from_grv_url(context->get(), url, head.data(), head.size()));
  }

  GraciaVideoStream get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }
  GraciaBBox bbox() const     { return h_ ? gracia_video_stream_bbox(h_.get()) : GraciaBBox {}; }
  // Runs the decoder one step. Returns true when the SDK decoded the frame and can
  // render it.
  bool ready() const          { return h_ && gracia_video_stream_ready(h_.get()); }
  // The maximum number of splats in one frame. Use it to set the renderer budget.
  uint64_t maxSplatsCount() const {
    return h_ ? gracia_video_stream_max_splats_count(h_.get()) : 0;
  }
  // The splats of the frame acquired. This changes with the frame.
  uint32_t splatsCount() const {
    return h_ ? gracia_video_stream_splats_count(h_.get()) : 0;
  }
  double duration() const     { return h_ ? gracia_video_stream_duration(h_.get()) : 0.0; }
  uint32_t audioSize() const  { return h_ ? gracia_video_stream_audio_size(h_.get()) : 0; }
  bool audioRead(char* buf) const { return h_ && gracia_video_stream_audio_read(h_.get(), buf); }
  // Where the video starts its viewer on one display, or none if it states none. See
  // GraciaViewpoint in SDK.h.
  std::optional<GraciaPose> viewpoint(GraciaViewpoint display) const {
    GraciaPose pose;
    if (!h_ || !gracia_video_stream_viewpoint(h_.get(), display, &pose)) return std::nullopt;
    return pose;
  }
  // The point that a viewer turns about, or none if the video states none. See
  // gracia_video_stream_pivot in SDK.h.
  std::optional<std::array<float, 3>> pivot() const {
    std::array<float, 3> p;
    if (!h_ || !gracia_video_stream_pivot(h_.get(), p.data())) return std::nullopt;
    return p;
  }
  // Bounds of the portal window, or none if the video states no portal. See
  // gracia_video_stream_portal_bbox in SDK.h.
  std::optional<GraciaBBox> portalBBox() const {
    GraciaBBox box;
    if (!h_ || !gracia_video_stream_portal_bbox(h_.get(), &box)) return std::nullopt;
    return box;
  }
  // Move of the portal subspace from the last rendered frame, or none if the
  // video states no portal. See gracia_video_stream_portal_follow in SDK.h.
  std::optional<std::array<float, 16>> portalFollow() const {
    std::array<float, 16> m;
    if (!h_ || !gracia_video_stream_portal_follow(h_.get(), m.data())) return std::nullopt;
    return m;
  }
  // Why the video plays nothing. See gracia_video_stream_status in SDK.h.
  GraciaVideoStatus status() const {
    return h_ ? gracia_video_stream_status(h_.get()) : GRACIA_VIDEO_STATUS_FAILED;
  }

  // Moves the playhead to `t` seconds. The next ready() or render decodes that frame.
  void setTime(double t)        { if (h_) gracia_video_stream_set_time(h_.get(), t); }
  void setPlaybackStart(double t) { if (h_) gracia_video_stream_set_playback_start(h_.get(), t); }
  void setPlaybackEnd(double t)   { if (h_) gracia_video_stream_set_playback_end(h_.get(), t); }
  // The speed at which you move the time. The sound of a GRV video plays at this
  // speed: 1 plays it as it is, and 0 pauses it. The default is 0. See
  // gracia_video_stream_set_speed in SDK.h.
  void setSpeed(double speed)   { if (h_) gracia_video_stream_set_speed(h_.get(), speed); }
  // Multiplies the gain of each sound of a GRV video. 1 is the default, and 0 mutes it.
  void setVolume(float volume)  { if (h_) gracia_video_stream_set_volume(h_.get(), volume); }
  void setTransform(const float* t) { if (h_) gracia_video_stream_set_transform(h_.get(), t); }
  // The same as StaticSplats::setEnvSH and setColorGrade (see SDK.h for the units and
  // the examples).
  void setEnvSH(const float* sh4x4) { if (h_) gracia_video_stream_set_env_sh(h_.get(), sh4x4); }
  void setColorGrade(float hue, float saturation, float value, float weight) {
    if (h_) gracia_video_stream_set_color_grade(h_.get(), hue, saturation, value, weight);
  }
  void setFlag(const char* key, bool value) { if (h_) gracia_video_stream_set_flag(h_.get(), key, value); }
  void setVisibility(float v) { if (h_) gracia_video_stream_set_visibility(h_.get(), v); }
  // Crops to a smaller box; see StaticSplats::setBboxMask for the coordinate system.
  void setBboxMask(
    float minX, float minY, float minZ,
    float maxX, float maxY, float maxZ, float falloff) {
    if (h_) gracia_video_stream_set_bbox_mask(
      h_.get(), minX, minY, minZ, maxX, maxY, maxZ, falloff);
  }
  void clearBboxMask() {
    if (h_) gracia_video_stream_clear_bbox_mask(h_.get());
  }

 private:
  explicit VideoStream(GraciaVideoStream handle) : h_(handle) {}

  detail::Handle<GraciaVideoStream, gracia_video_stream_destroy> h_;
};

// Writes the C handles for `splats` into `out` (which must hold at least splats.size()).
inline void fillSplatsObjectHandles(
  std::span<const std::variant<StaticSplats*, VideoStream*>> splats,
  GraciaSplatsObject* out
) {
  for (size_t i = 0; i < splats.size(); ++i) {
    std::visit([&](auto* p) {
      constexpr bool isVideo = std::is_same_v<std::decay_t<decltype(*p)>, VideoStream>;
      out[i] = {p ? p->get() : nullptr, isVideo};
    }, splats[i]);
  }
}

inline DrawCalls SdkSplatsRenderer::render(
  std::span<const std::variant<StaticSplats*, VideoStream*>> splats,
  const float* const* projections, const float* const* viewTransforms,
  const float* locomotionTransform,
  uint32_t targetWidth, uint32_t targetHeight,
  bool vr,
  const GraciaRendererSplatsPass& splatsPass,
  const GraciaRendererMotionPass* motionPass,
  const GraciaRendererMeshPass* meshPass,
  GraciaCommandBuffer commandBuffer
) {
  if (!h_ || splats.empty()) return {};

  std::array<GraciaSplatsObject, 16> stackObjs;
  std::vector<GraciaSplatsObject> heapObjs;
  GraciaSplatsObject* objs = stackObjs.data();
  if (splats.size() > stackObjs.size()) {
    heapObjs.resize(splats.size());
    objs = heapObjs.data();
  }
  fillSplatsObjectHandles(splats, objs);

  auto raw = gracia_splats_renderer_render(
    h_.get(), objs, uint32_t(splats.size()),
    projections, viewTransforms, locomotionTransform,
    targetWidth, targetHeight, vr,
    &splatsPass, motionPass, meshPass,
    commandBuffer
  );

  DrawCalls result;
  result.buffering = raw.buffering;
  result.compiling = raw.compiling;
  result.color = detail::passOf(raw.color);
  result.depth = detail::passOf(raw.depth);
  result.motion = detail::passOf(raw.motion);
  result.mesh = detail::passOf(raw.mesh);
  return result;
}

// Returns the MINT content version from a file on disk (0 if the file is not a valid
// MINT).
inline uint32_t videoMintVersionFromFile(const std::filesystem::path& path) {
  return gracia_video_mint_version_from_file(path.c_str());
}

// Returns the MINT content version from a header string (0 if the SDK cannot parse
// it).
inline uint32_t videoMintVersionFromHead(const std::string& head) {
  return gracia_video_mint_version_from_head(head.c_str());
}

// Trackball orbit and fly camera with inertia (CPU only). See gracia_camera_* in SDK.h.
class Camera {
 public:
  explicit Camera(GraciaCameraConfig config = {60.0f, 1.0f, 1.0f, true, true})
      : h_(gracia_camera_create(&config)) {}

  GraciaCamera get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }

  GraciaCameraConfig config() const { return gracia_camera_config(h_.get()); }
  void setConfig(GraciaCameraConfig cfg) { if (h_) gracia_camera_set_config(h_.get(), cfg); }

  void frame(GraciaCameraScene scene) { if (h_) gracia_camera_frame(h_.get(), scene); }
  void frame(GraciaBBox full, std::optional<GraciaBBox> adaptive = std::nullopt,
             std::optional<std::array<float, 3>> pivot = std::nullopt, bool reposition = true) {
    GraciaCameraScene s {};
    s.bounds = full;
    if (adaptive) s.adaptive = *adaptive;
    if (pivot) {
      s.pivot[0] = (*pivot)[0];
      s.pivot[1] = (*pivot)[1];
      s.pivot[2] = (*pivot)[2];
      s.hasPivot = true;
    }
    s.keepPose = !reposition;
    frame(s);
  }
  void place(GraciaPose pose) { if (h_) gracia_camera_place(h_.get(), pose); }
  void follow(const float move[16]) { if (h_) gracia_camera_follow(h_.get(), move); }
  void reset() { if (h_) gracia_camera_reset(h_.get()); }

  void input(GraciaCameraDelta delta) { if (h_) gracia_camera_input(h_.get(), delta); }
  void zoom(float factor) { if (factor > 0.0f) input({.zoom = std::log(factor)}); }
  void setKeys(uint32_t keyMask) { if (h_) gracia_camera_set_keys(h_.get(), keyMask); }
  bool update(float dt) { return h_ && gracia_camera_update(h_.get(), dt); }

  GraciaCameraView view(float aspect = 0.0f, float viewHeight = 0.0f) {
    return gracia_camera_view(h_.get(), aspect, viewHeight);
  }

 private:
  detail::Handle<GraciaCamera, gracia_camera_destroy> h_;
};

// Model matrix placing content at full size so its VR viewpoint aligns with `head`.
inline std::array<float, 16> vrPlacement(GraciaPose viewpoint, const float head[16]) {
  std::array<float, 16> out {};
  gracia_vr_placement(viewpoint, head, out.data());
  return out;
}

}  // namespace gracia
