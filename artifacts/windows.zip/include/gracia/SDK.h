#pragma once

#include <stdbool.h>
#include <stdint.h>

/* No exception crosses this interface: a function that fails inside gives the value
   that its comment states for a failure, as for a null handle. */

/* Call the functions of one context, and of each object that it makes, from one
   thread at a time: the setters of an object take no lock against a render.
   gracia_audio_read alone runs on the audio thread of the caller, beside them. */

/* A path string is a wide string (UTF-16) on Windows, or a UTF-8 char* on other
   systems. */
#ifdef _WIN32
#include <wchar.h>
typedef const wchar_t* PathStr;
#else
typedef const char* PathStr;
#endif

/* The SDK renders with the caller's own graphics objects: Metal on Apple, or
   Vulkan on other systems. This header includes the correct platform header, thus
   the handle types below (VkDevice, id<MTLDevice>) are available. */
#ifdef __APPLE__
  #import <Metal/Metal.h>
#else
  #ifndef VK_NO_PROTOTYPES
  #define VK_NO_PROTOTYPES
  #endif
  #include <vulkan/vulkan.h>
#ifdef __linux__
  #undef Bool
  #undef None
  #undef Always
  #undef Front
  #undef Back
  #undef Success
  #undef Status
#endif
#endif

/* PUBLIC_API marks each exported symbol. It is dllexport when you build the SDK,
   or dllimport (or default visibility) when you use the SDK. */
#ifdef _WIN32
#ifdef SDK_BUILD
#define PUBLIC_API __declspec(dllexport)
#else
#define PUBLIC_API __declspec(dllimport)
#endif
#else
#ifdef SDK_BUILD
#define PUBLIC_API __attribute__((visibility("default")))
#else
#define PUBLIC_API
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================================
   Opaque handles
   ============================================================================ */

typedef struct GraciaContextImpl*       GraciaContext;
typedef struct GraciaRendererImpl*      GraciaRenderer;
typedef struct GraciaStaticSplatsImpl*  GraciaStaticSplats;
typedef struct GraciaVideoDescImpl*     GraciaVideoDesc;
typedef struct GraciaVideoStreamImpl*   GraciaVideoStream;
typedef struct GraciaDepthResolverImpl* GraciaDepthResolver;
typedef struct GraciaDrawCallImpl*      GraciaDrawCall;
typedef struct GraciaCameraImpl*        GraciaCamera;

/* ============================================================================
   Value types
   ============================================================================ */

/* An axis-aligned bounding box, in the local space of the content, before the
   transform. The layout is {minX, minY, minZ, maxX, maxY, maxZ}. An empty box is
   all zero. */
typedef struct GraciaBBox {
  float minmax[6];
} GraciaBBox;

/* A rigid placement. `position` is {x, y, z}, and `rotation` is a unit quaternion
   {x, y, z, w}. */
typedef struct GraciaPose {
  float position[3];
  float rotation[4];
} GraciaPose;

/* The display of a viewpoint: where a video starts its viewer. A viewpoint is the
   camera-to-world pose of the eye, in the local space of the content, before the
   transform. The eye looks along its -Z, with +Y up.
     DISPLAY - a flat screen. Show the pose with a vertical field of view of 60
               degrees, the lens of Gracia Studio.
     VR      - a headset. Move the content so that the pose is where the headset
               is at its first frame: the eye of the headset at the place of the
               pose, upright, in the heading of the pose. The headset keeps its
               tilt. A runtime can put the origin of its space anywhere. */
typedef enum GraciaViewpoint {
  GRACIA_VIEWPOINT_DISPLAY = 0,
  GRACIA_VIEWPOINT_VR = 1,
} GraciaViewpoint;

/* Why a video stream plays nothing (see gracia_video_stream_status). The SDK states
   no more of the cause. */
typedef enum GraciaVideoStatus {
  GRACIA_VIDEO_STATUS_OK = 0,           /* the video plays, or its head is not in yet */
  GRACIA_VIDEO_STATUS_FAILED = 1,       /* the file does not play */
  GRACIA_VIDEO_STATUS_UNSUPPORTED = 2,  /* the file needs a newer SDK */
  GRACIA_VIDEO_STATUS_HEAD_HASH = 3,    /* the file holds a head hash, and opens only with its head */
} GraciaVideoStatus;

/* The container format of a splat asset. PLY, GUF, and SOG are static files with
   one frame. MINT is the video format. UNKNOWN is a format that the SDK does not
   know. */
typedef enum GraciaContentType {
  GRACIA_CONTENT_UNKNOWN = 0,
  GRACIA_CONTENT_PLY = 1,
  GRACIA_CONTENT_GUF = 2,
  GRACIA_CONTENT_MINT = 3,
  GRACIA_CONTENT_SOG = 4,
} GraciaContentType;

/* The pixel format of a color render target that the caller supplies for a pass. */
typedef enum GraciaColorFormat {
  GRACIA_COLOR_FORMAT_UNDEFINED  = 0,  /* no color output; the SDK skips the pass */
  GRACIA_COLOR_FORMAT_RGBA8_UNORM = 1,
  GRACIA_COLOR_FORMAT_RGBA8_SRGB  = 2,
  GRACIA_COLOR_FORMAT_RGBA16_FLOAT = 3,
  GRACIA_COLOR_FORMAT_RG16_FLOAT   = 4,  /* motion vectors */
  GRACIA_COLOR_FORMAT_RGBA32_FLOAT = 5,
} GraciaColorFormat;

/* The pixel format of a depth (or depth and stencil) render target. */
typedef enum GraciaDepthFormat {
  GRACIA_DEPTH_FORMAT_UNDEFINED = 0,  /* no depth attachment */
  GRACIA_DEPTH_FORMAT_D16_UNORM = 1,
  GRACIA_DEPTH_FORMAT_D32_FLOAT = 2,
  GRACIA_DEPTH_FORMAT_D24_UNORM_S8_UINT = 3,
  GRACIA_DEPTH_FORMAT_D32_FLOAT_S8_UINT = 4,
} GraciaDepthFormat;

/* The method that the SDK uses to make stereo (two-eye) output:
     MULTIPASS  - one draw call for each eye, into separate single-layer targets.
     MULTIVIEW  - one draw call writes both layers through a view mask.
     MULTILAYER - one pass writes both layers of a two-layer array target.
   For mono output, the mode has no effect: the SDK gives one view. */
typedef enum GraciaStereoMode {
  GRACIA_STEREO_MODE_MULTIPASS  = 0,
  GRACIA_STEREO_MODE_MULTIVIEW  = 1,
  GRACIA_STEREO_MODE_MULTILAYER = 2,
} GraciaStereoMode;

/* The depth test that the pass uses to keep or to remove a fragment. A reverse-Z
   scene (near = 1, far = 0) uses GREATER or GREATER_OR_EQUAL. */
typedef enum GraciaCompareOp {
  GRACIA_COMPARE_OP_NEVER            = 0,
  GRACIA_COMPARE_OP_LESS             = 1,
  GRACIA_COMPARE_OP_EQUAL            = 2,
  GRACIA_COMPARE_OP_LESS_OR_EQUAL    = 3,
  GRACIA_COMPARE_OP_GREATER          = 4,
  GRACIA_COMPARE_OP_NOT_EQUAL        = 5,
  GRACIA_COMPARE_OP_GREATER_OR_EQUAL = 6,
  GRACIA_COMPARE_OP_ALWAYS           = 7,
} GraciaCompareOp;

/* The depth state for a pass. `test` and `write` turn the depth test and the depth
   writes on or off. `compareOp` is the condition to keep a fragment. `clamp` turns
   on the depth clamp (no near or far clip). Set `format` to UNDEFINED for a pass
   with no depth attachment. */
typedef struct GraciaDepthDescription {
  GraciaDepthFormat format;
  bool test;
  bool write;
  GraciaCompareOp compareOp;
  bool clamp;
} GraciaDepthDescription;

/* The setup of the main splats pass: the color target format, the depth state, the
   MSAA sample count, and the stereo method for the color output and the depth
   output. The two stereo methods can be different (for example, multiview color
   with multipass depth). `fragmentDensityMap` must match the density map attachment
   of the caller's color pass. It does not apply to the internal depth-data pass.
   Vulkan only: the caller enables VK_EXT_fragment_density_map and its device
   features, then supplies the attachment. Set false for a pass without a density
   map. Metal ignores this field. */
typedef struct GraciaRendererSplatsPass {
  GraciaColorFormat colorFormat;
  GraciaDepthDescription depth;
  uint32_t sampleCount;
  GraciaStereoMode stereo;
  GraciaStereoMode depthStereo;
  bool fragmentDensityMap;
} GraciaRendererSplatsPass;

/* An optional motion-vector pass. `invertPosY` and `invertColorY` flip the Y axis
   of the positions and the motion values, to agree with the coordinate system of
   the target. `fragmentDensityMap` must match this pass, with the same Vulkan
   requirements as GraciaRendererSplatsPass. Metal ignores it. */
typedef struct GraciaRendererMotionPass {
  GraciaColorFormat colorFormat;
  GraciaDepthDescription depth;
  bool invertPosY;
  bool invertColorY;
  uint32_t sampleCount;
  GraciaStereoMode stereo;
  bool fragmentDensityMap;
} GraciaRendererMotionPass;

/* An optional proxy-mesh pass. The mesh is geometry that fits the splats, for
   example for occlusion or shadows. `invertPosY` flips the clip-space Y.
   `disableColorWrite` writes depth only. `fragmentDensityMap` must match this
   pass, with the same Vulkan requirements as GraciaRendererSplatsPass. Metal
   ignores it. */
typedef struct GraciaRendererMeshPass {
  GraciaColorFormat colorFormat;
  GraciaDepthDescription depth;
  bool invertPosY;
  bool disableColorWrite;
  uint32_t sampleCount;
  GraciaStereoMode stereo;
  bool fragmentDensityMap;
} GraciaRendererMeshPass;

/* Apple only. The tile dimensions and the sample storage for each pixel, for the
   splat blend in tile memory. Use these values in the MTLRenderPass tile setup of
   the caller. */
typedef struct GraciaMetalTileSettings {
  uint32_t width;
  uint32_t height;
  uint32_t imageblockSampleLength;
} GraciaMetalTileSettings;

/* Where the SDK sends the sound of each video:
     NONE   - nowhere. A video plays no sound and fetches no chunk of a sound. This is
              the default (zero).
     DEVICE - the default playback device of the system. The SDK opens it. On iOS and
              visionOS the caller sets the category of its AVAudioSession, for example
              Playback, and the SDK does not change it.
     HOST   - the caller. The SDK opens no device, and the caller reads the mix with
              gracia_audio_read, for example into the audio engine of a game engine. */
typedef enum GraciaAudioOutput {
  GRACIA_AUDIO_OUTPUT_NONE = 0,
  GRACIA_AUDIO_OUTPUT_DEVICE = 1,
  GRACIA_AUDIO_OUTPUT_HOST = 2,
} GraciaAudioOutput;

/* The audio of a context. `sampleRate` and `channels` apply to HOST only: they are
   the format of the frames that gracia_audio_read writes. Zero gives 48000 frames a
   second and 2 channels. A device keeps its own format. */
typedef struct GraciaAudioDescriptor {
  GraciaAudioOutput output;
  uint32_t sampleRate;
  uint32_t channels;
} GraciaAudioDescriptor;

/* The GPU objects that the caller owns and that the SDK renders with. The caller
   keeps ownership of all handles, and each handle must exist while the context
   exists.
     Apple:  an MTLDevice and an MTLCommandQueue.
     Vulkan: the instance, the device, and the queues, with the loader entry point.
             The three queue family indexes can be equal.
   `asyncCompile` selects how the SDK compiles its GPU pipelines. The default (zero)
   is false.
     false: at once, in the SDK call that needs the pipeline. Thus the first render
            of an object can take more time.
     true:  on a thread of the SDK. A render skips each object until its pipelines
            are ready, and sets `compiling` (see GraciaDrawCalls).
   `audio` selects where the sound of each video goes (see GraciaAudioDescriptor). */
typedef struct GraciaContextDescriptor {
#ifdef __APPLE__
  __unsafe_unretained id<MTLDevice>       device;
  __unsafe_unretained id<MTLCommandQueue> commandQueue;
#else
  PFN_vkGetInstanceProcAddr getInstanceProcAddr;
  VkInstance instance;
  VkPhysicalDevice physicalDevice;
  VkDevice device;
  uint32_t graphicsQueueFamilyIndex;
  uint32_t computeQueueFamilyIndex;
  uint32_t transferQueueFamilyIndex;
#endif
  bool asyncCompile;
  GraciaAudioDescriptor audio;
} GraciaContextDescriptor;

/* This structure holds the native command buffer of the caller. On Metal, the SDK
   writes commands into this handle, thus the handle must be a live
   MTLCommandBuffer. On Vulkan, the SDK uses its own command buffer, thus it ignores
   `handle` (pass {0}). */
typedef struct GraciaCommandBuffer {
#ifdef __APPLE__
  __unsafe_unretained id<MTLCommandBuffer> handle;
#else
  VkCommandBuffer handle;
#endif
} GraciaCommandBuffer;

/* The active render pass or encoder of the caller. gracia_draw_call_execute replays
   a draw call into it. On Metal, supply the MTLRenderCommandEncoder. On Vulkan,
   supply the command buffer in an open render pass, with that VkRenderPass and the
   index of the subpass the recording is in. */
typedef struct GraciaRenderPass {
#ifdef __APPLE__
  __unsafe_unretained id<MTLRenderCommandEncoder> encoder;
#else
  VkCommandBuffer commandBuffer;
  VkRenderPass renderPass;
  uint32_t subpass;
#endif
} GraciaRenderPass;

/* The recorded draw calls of one pass, one for each view. `views[v]` is an opaque
   draw-call handle, or NULL if the view has no output. Execute it with
   gracia_draw_call_execute, then release it with gracia_draw_call_destroy.
   `viewCount` is the number of valid entries (1 for mono, 2 for stereo).
   `stereoMode` is the method that the SDK recorded these calls for. */
typedef struct GraciaPassDrawCalls {
  GraciaDrawCall views[2];
  uint32_t viewCount;
  GraciaStereoMode stereoMode;
} GraciaPassDrawCalls;

/* All draw calls that one gracia_splats_renderer_render call makes. Execute each
   pass into the correct attachments of the caller. `buffering` is true when a video
   object did not decode the requested frame yet. Then the draw calls are not
   complete: do not present this frame, and do the render again. `compiling` is true
   while a thread of the SDK compiles the GPU pipelines of the objects (see
   `asyncCompile` in GraciaContextDescriptor). Then the draw calls do not have all
   objects. A render starts these compiles itself. */
typedef struct GraciaDrawCalls {
  GraciaPassDrawCalls color;
  GraciaPassDrawCalls depth;
  GraciaPassDrawCalls motion;
  GraciaPassDrawCalls mesh;
  bool buffering;
  bool compiling;
} GraciaDrawCalls;

/* An object to render. `ptr` is a static-splats handle (gracia_static_splats_create)
   or a video-stream handle (gracia_video_stream_create*). `isVideo` selects which
   one. */
typedef struct GraciaSplatsObject {
  void* ptr;
  bool isVideo;
} GraciaSplatsObject;

/* ============================================================================
   MINT video probe (no GPU and no context necessary)
   ============================================================================ */

/* Returns true if the SDK can decode this MINT header (the raw ".head" bytes, or
   the stream header string). Use it to find an unsupported stream before you open
   it. */
PUBLIC_API bool gracia_video_head_supported(const char* head);
/* Returns the MINT content version from a header string, or 0 if the SDK cannot
   parse it. */
PUBLIC_API uint32_t gracia_video_mint_version_from_head(const char* head);
/* Returns the MINT content version from a file on disk, or 0 if the file is not a
   valid MINT. */
PUBLIC_API uint32_t gracia_video_mint_version_from_file(PathStr videoFilePath);

/* ============================================================================
   Context: one for each GPU session
   ============================================================================ */

/* Creates the SDK session. The session holds the pipelines and the GPU memory.
   `cacheDir` (can be NULL) is a directory with write access for the shader and
   asset cache on disk. On Vulkan, the SDK keeps its pipeline cache there. Without
   `cacheDir`, the SDK compiles its pipelines again in each session. Returns an opaque
   context handle, or NULL if it fails. The caller makes all other objects from this
   context, and must destroy them before the context. */
PUBLIC_API GraciaContext gracia_context_create(
  const GraciaContextDescriptor* descriptor, PathStr cacheDir);
/* Destroys a context and releases its GPU resources. */
PUBLIC_API void gracia_context_destroy(GraciaContext context);
/* Returns the number of bytes that the GPU allocator of the SDK holds now. Use it
   to measure the memory change around create and destroy. */
PUBLIC_API uint64_t gracia_context_gpu_allocated_bytes(GraciaContext context);

/* ============================================================================
   Audio: the one mix of the sounds of all videos of a context
   ============================================================================ */

/* Puts the listener at a camera. `cameraToWorld` is a column-major 4x4 float[16],
   the same matrix that a render takes as a view transform. The listener hears along
   its -Z, with +Y up. Call it each frame, with the camera of the frame (in VR, the
   head between the two eyes). Before the first call, the listener is at the origin. */
PUBLIC_API void gracia_audio_set_listener(GraciaContext context, const float* cameraToWorld);
/* HOST output only. Mixes the next `frameCount` frames of the sound of all videos
   into `frames`, interleaved float32, in the format of the GraciaAudioDescriptor.
   Call it on the audio thread of the caller, as often as the caller plays frames.
   Returns false, and writes nothing, if the output of the context is not HOST. */
PUBLIC_API bool gracia_audio_read(GraciaContext context, float* frames, uint32_t frameCount);

/* ============================================================================
   Splats renderer
   ============================================================================ */

/* Creates a renderer for a maximum of `maxSplatsCount` visible splats in one frame.
   This count is the total for all objects in one render call. Set `vr` to true for
   two-eye output; a mono renderer cannot render stereo later. `legacyPipeline`
   selects the compute shaders that prepare and sort the splats.
     false: the shaders with subgroup operations when the GPU supports them, else
            the legacy pipeline.
     true:  the legacy pipeline on all GPUs. It has no subgroup operations. Use it
            when the GPU driver does not do subgroup operations correctly. On some
            GPUs the legacy pipeline is slower.
   Returns an opaque renderer handle, or NULL if it fails. */
PUBLIC_API GraciaRenderer gracia_splats_renderer_create(
  GraciaContext context,
  uint32_t maxSplatsCount,
  bool vr,
  bool legacyPipeline);
/* Destroys a renderer. */
PUBLIC_API void gracia_splats_renderer_destroy(GraciaRenderer renderer);

/* ============================================================================
   Static splats (one-frame PLY / GUF / SOG)
   ============================================================================ */

/* Loads a static splat asset. `headerData` is an optional header in memory for a
   split head-and-body asset (NULL for one file). `filePath` is the body file or the
   whole file. `contentType` must be PLY, GUF, or SOG (not MINT or UNKNOWN). Returns
   an opaque splats handle, or NULL if it fails. */
PUBLIC_API GraciaStaticSplats gracia_static_splats_create(
  GraciaContext context, const char* headerData,
  PathStr filePath, GraciaContentType contentType);
/* Destroys a static splats handle. */
PUBLIC_API void gracia_static_splats_destroy(GraciaStaticSplats splats);
/* Returns the number of splats in the asset (0 if the SDK did not load it). */
PUBLIC_API uint32_t gracia_static_splats_count(GraciaStaticSplats splats);
/* Returns the full axis-aligned bounds of all splats, in the local space of the
   asset. */
PUBLIC_API GraciaBBox gracia_static_splats_bbox(GraciaStaticSplats splats);
/* Returns a bounds that ignores distant splats: the 10th to 90th percentile of the
   splat positions on each axis. It is better than bbox() to frame a camera
   automatically, because distant splats can make bbox() too large. */
PUBLIC_API GraciaBBox gracia_static_splats_adaptive_bbox(GraciaStaticSplats splats);
/* Sets the model transform, as a column-major 4x4 float[16] (local to world). */
PUBLIC_API void gracia_static_splats_set_transform(GraciaStaticSplats splats, const float* transform);
/* Relights the splats with a first-order (L1) spherical-harmonic environment probe.
   The SDK evaluates the probe for each splat, toward the camera, and multiplies it
   into the color of the splat.
   `sh4x4` is 4 rows of 4 floats (pass NULL to turn this off):
     row0 = base RGB, and w = strength in [0,1] (0 turns it off)
     row1 = directional RGB toward +Y (up)
     row2 = directional RGB toward +Z (front)
     row3 = directional RGB toward +X (right)
   The SH C0 factor is near 0.282. Thus a base value near 3.5 gives an almost
   neutral result (no tint). Example - soft daylight from above:
     const float sh[16] = {
       3.62f, 3.54f, 3.37f, 1.0f,   // base RGB and strength
       0.50f, 0.45f, 0.40f, 0.0f,   // warm tint from above
       0.00f, 0.00f, 0.00f, 0.0f,   // +Z
       0.00f, 0.00f, 0.00f, 0.0f,   // +X
     };
     gracia_static_splats_set_env_sh(splats, sh); */
PUBLIC_API void gracia_static_splats_set_env_sh(GraciaStaticSplats splats, const float* sh4x4);
/* Grades the color of each splat in HSV space:
     hue        - the SDK adds this to the hue and wraps it (a turn; 0.33 is near
                  +120 degrees; a value less than 0 is valid)
     saturation - the SDK multiplies the saturation (1 keeps it, 0 gives grayscale,
                  a value more than 1 gives more saturation)
     value      - the SDK multiplies the brightness (1 keeps it, less than 1 is
                  darker, more than 1 is brighter)
     weight     - the SDK mixes the graded color over the original color, in [0,1]
                  (0 or less makes no change)
   Example - warm, with a small increase in brightness:
     gracia_static_splats_set_color_grade(splats, 0.04f, 1.15f, 1.05f, 1.0f);
   Example - full grayscale:
     gracia_static_splats_set_color_grade(splats, 0.0f, 0.0f, 1.0f, 1.0f); */
PUBLIC_API void gracia_static_splats_set_color_grade(
  GraciaStaticSplats splats, float hue, float saturation, float value, float weight);
/* Turns a named feature of the object on or off. */
PUBLIC_API void gracia_static_splats_set_flag(GraciaStaticSplats splats, const char* key, bool value);
/* Sets the opacity multiplier of the whole object, in [0,1]. 1 is fully visible,
   0 is hidden. A value between the two makes the object fade with dithered
   visibility. */
PUBLIC_API void gracia_static_splats_set_visibility(GraciaStaticSplats splats, float visibility);

/* Crops the content to a smaller box, and fades the splats outside it smoothly. The
   six min and max values are normalized on each axis, in [-1, 1], against bbox()
   (-1 is the box minimum, +1 is the box maximum). Thus {-1,-1,-1, 1,1,1} keeps all
   splats. `falloff`, in [0, 1], is the width of the soft edge (0 is a hard cut). */
PUBLIC_API void gracia_static_splats_set_bbox_mask(
  GraciaStaticSplats splats, float minX, float minY, float minZ,
  float maxX, float maxY, float maxZ, float falloff);
/* Removes a bbox mask that you set before, and shows the whole object again. */
PUBLIC_API void gracia_static_splats_clear_bbox_mask(GraciaStaticSplats splats);

/* ============================================================================
   Video descriptor: metadata only, no GPU decode
   ============================================================================ */

/* Reads the layout of a MINT file for its metadata (bounds, duration, audio), and
   does not make a GPU stream. `head` is an optional header in memory for a split
   head-and-body asset (NULL for one file). Returns a handle, or NULL if it fails. */
PUBLIC_API GraciaVideoDesc gracia_video_desc_create(const char* head, PathStr videoFilePath);
/* Destroys a video descriptor. */
PUBLIC_API void gracia_video_desc_destroy(GraciaVideoDesc desc);
/* Returns the authored bounds from the MINT layout. You can read this value before
   the SDK decodes any frame. */
PUBLIC_API GraciaBBox gracia_video_desc_bbox(GraciaVideoDesc desc);
/* Returns the total duration, in seconds. */
PUBLIC_API double gracia_video_desc_duration(GraciaVideoDesc desc);
/* Returns the size, in bytes, of the audio data, or 0 if there is none. */
PUBLIC_API uint32_t gracia_video_desc_audio_size(GraciaVideoDesc desc);
/* Copies the audio data into `buffer`. Allocate audio_size() bytes first. Returns
   false if there is no audio, or if the read fails. */
PUBLIC_API bool gracia_video_desc_audio_read(GraciaVideoDesc desc, char* buffer);

/* ============================================================================
   Video stream: decodes MINT frames to GPU splats over time
   ============================================================================ */

/* Opens a MINT or GRV video for playback. `mintHead` is an optional header in memory
   for a split head-and-body MINT asset (NULL for one file). Set `needMesh` to true to
   also decode the proxy mesh stream. `head` is the head of a GRV video that holds a
   head hash, `headSize` bytes: the file of the video with ".head" after its name
   holds it (NULL for none). The SDK copies the head, and a video that holds no head
   hash ignores it. Returns an opaque stream handle, or NULL if it fails. */
PUBLIC_API GraciaVideoStream gracia_video_stream_create(
  GraciaContext context, const char* mintHead, PathStr videoFilePath, bool needMesh,
  const void* head, uint64_t headSize);
/* Opens a MINT video from an http:// or https:// URL, with an optional access token
   (NULL for none): with a token, through the API. Returns a handle, or NULL if it
   fails: also for a URL of another scheme, and for a token that holds a carriage
   return or a line feed. */
PUBLIC_API GraciaVideoStream gracia_video_stream_create_from_url(
  GraciaContext context, const char* url, const char* token);
/* Opens a GRV video from an http:// or https:// URL. `head` and `headSize` are as for
   gracia_video_stream_create. Returns a handle, or NULL if it fails: also for a URL of
   another scheme. */
PUBLIC_API GraciaVideoStream gracia_video_stream_create_from_grv_url(
  GraciaContext context, const char* url, const void* head, uint64_t headSize);
/* Destroys a video stream. */
PUBLIC_API void gracia_video_stream_destroy(GraciaVideoStream stream);
/* Returns the bounds of the current content, in local space. */
PUBLIC_API GraciaBBox gracia_video_stream_bbox(GraciaVideoStream stream);
/* Runs the decoder one step, and returns true when the SDK decoded the current
   frame and can render it. Call this function after a seek, and each frame, before
   you render. */
PUBLIC_API bool gracia_video_stream_ready(GraciaVideoStream stream);
/* Returns the maximum number of splats in one frame. Use it to set the renderer
   budget. */
PUBLIC_API uint64_t gracia_video_stream_max_splats_count(GraciaVideoStream stream);
/* Returns the splats of the frame acquired, which is what the last render was
   asked to draw. Unlike the maximum this changes with the frame, so it is what
   says whether a frame held everything on screen at that instant. */
PUBLIC_API uint32_t gracia_video_stream_splats_count(GraciaVideoStream stream);
/* Moves the playhead to `time` seconds. The next ready() or render decodes that
   frame. */
PUBLIC_API void gracia_video_stream_set_time(GraciaVideoStream stream, double time);
/* Sets the start time of playback, in seconds. */
PUBLIC_API void gracia_video_stream_set_playback_start(GraciaVideoStream stream, double time);
/* Sets the end time of playback, in seconds. */
PUBLIC_API void gracia_video_stream_set_playback_end(GraciaVideoStream stream, double time);
/* Sets the model transform, as a column-major 4x4 float[16] (local to world). */
PUBLIC_API void gracia_video_stream_set_transform(GraciaVideoStream stream, const float* transform);
/* Applies an environment SH relight. The layout and the example are the same as
   gracia_static_splats_set_env_sh (NULL turns it off). */
PUBLIC_API void gracia_video_stream_set_env_sh(GraciaVideoStream stream, const float* sh4x4);
/* Applies an HSV color grade. The parameters and the examples are the same as
   gracia_static_splats_set_color_grade. */
PUBLIC_API void gracia_video_stream_set_color_grade(
  GraciaVideoStream stream, float hue, float saturation, float value, float weight);
/* Turns a named feature of the object on or off; the same as
   gracia_static_splats_set_flag. */
PUBLIC_API void gracia_video_stream_set_flag(GraciaVideoStream stream, const char* key, bool value);
/* Sets the opacity multiplier of the whole object, in [0,1]; see
   gracia_static_splats_set_visibility. */
PUBLIC_API void gracia_video_stream_set_visibility(GraciaVideoStream stream, float visibility);
/* Crops the content to a smaller box; the ranges are the same as
   gracia_static_splats_set_bbox_mask. */
PUBLIC_API void gracia_video_stream_set_bbox_mask(
  GraciaVideoStream stream, float minX, float minY, float minZ,
  float maxX, float maxY, float maxZ, float falloff);
/* Removes a bbox mask that you set before. */
PUBLIC_API void gracia_video_stream_clear_bbox_mask(GraciaVideoStream stream);
/* Returns the total duration, in seconds. A GRV video is as long as its file states:
   from 0 to the latest end of a chunk of the file. */
PUBLIC_API double gracia_video_stream_duration(GraciaVideoStream stream);
/* Sets the speed at which the caller moves the time of the video (see
   gracia_video_stream_set_time). The sound of a GRV video plays at this speed, at
   the time of the video and at its own pitch: 1 plays it as it is, and 0 pauses it.
   The default is 0, thus
   a video plays no sound until the caller sets a speed. Set 0 while you pause, while
   you hold the time for any reason, and while you scrub or rewind. The sound follows
   each jump of the time, it pauses itself while the video buffers, and it plays only
   at a speed from 0.5 to 2. The video loads the chunks of its sound with those of its
   picture at any speed, and a frame waits for both. */
PUBLIC_API void gracia_video_stream_set_speed(GraciaVideoStream stream, double speed);
/* Multiplies the gain of each sound of a GRV video. 1 is the default, and 0 mutes it. */
PUBLIC_API void gracia_video_stream_set_volume(GraciaVideoStream stream, float volume);
/* Returns the size, in bytes, of the audio data, or 0 if there is none. */
PUBLIC_API uint32_t gracia_video_stream_audio_size(GraciaVideoStream stream);
/* Copies the audio data into `buffer`. Allocate audio_size() bytes first. */
PUBLIC_API bool gracia_video_stream_audio_read(GraciaVideoStream stream, char* buffer);
/* Writes into `out` the viewpoint of the video for one display (see
   GraciaViewpoint). Returns false, and writes nothing, if the video states no such
   viewpoint, or before its metadata comes in. Only a GRV video can state one. */
PUBLIC_API bool gracia_video_stream_viewpoint(
  GraciaVideoStream stream, GraciaViewpoint viewpoint, GraciaPose* out);
/* Writes into `out` the pivot of the video: the point that a viewer turns about. The
   pivot is in the local space of the content, before the transform, as a viewpoint is.
   Turn an orbit camera about it, and frame the content about it. Returns false, and
   writes nothing, if the video states no pivot, or before its metadata comes in. Only a
   GRV video can state one. */
PUBLIC_API bool gracia_video_stream_pivot(GraciaVideoStream stream, float out[3]);
/* Writes into `out` the bounds of the portal window of the video, in the local
   space of the content before the transform. Returns false, and writes nothing,
   if the video states no portal, or before its metadata comes in. Only a GRV
   video can state one. */
PUBLIC_API bool gracia_video_stream_portal_bbox(GraciaVideoStream stream, GraciaBBox* out);
/* Writes into `out` the column-major 4x4 move of the subspace of the portal of
   the video from the last rendered frame. Move the camera pivot by this matrix
   so an orbit tracks a portal that follows the viewer. Returns false, and writes
   nothing, if the video states no portal, or before its metadata comes in. Only
   a GRV video can state one. */
PUBLIC_API bool gracia_video_stream_portal_follow(GraciaVideoStream stream, float out[16]);
/* Returns why the video plays nothing (see GraciaVideoStatus). ready() reads the head,
   thus call this function after ready() returns false. A status other than OK does not
   change: destroy the stream, and open a HEAD_HASH video again with its head. Only a GRV
   video gives a status other than OK. */
PUBLIC_API GraciaVideoStatus gracia_video_stream_status(GraciaVideoStream stream);

/* ============================================================================
   Render calls
   ============================================================================ */

/* Apple only. Returns the tile settings for the splats pass, for its pipeline setup.
   Use these values in the MTLRenderPass that executes the color and depth draw
   calls, thus the tile blend gets the correct imageblock memory. */
PUBLIC_API GraciaMetalTileSettings gracia_splats_renderer_metal_tile_settings(
  GraciaRenderer renderer, const GraciaRendererSplatsPass* splatsPass);

/* Prepares a frame and records its draw calls. The inputs are:
     splatsObjects, splatsObjectsCount - the objects to draw in this frame.
     projections, viewTransforms - arrays of pointers to column-major 4x4 float[16].
       Index 0 is the (left) eye. When `vr` is true, index 1 is the right eye.
     locomotionTransform - a column-major 4x4 matrix for the right-eye reprojection
       in VR (pass an identity matrix if you do not use it).
     targetWidth, targetHeight - the size of the render target, in pixels.
     vr - true to make stereo output (create the renderer with vr = true first).
     splatsPass - necessary. motionPass and meshPass - optional (NULL to skip a
       pass).
     commandBuffer - the command buffer of the caller on Metal; the SDK ignores it
       on Vulkan.
   Returns a GraciaDrawCalls. The caller executes the handle of each view into its
   own attachments (see gracia_draw_call_execute), then destroys the handle. If
   `buffering` is true, a video frame was not ready and the result is not complete:
   do not present this frame, and do the render again. */
PUBLIC_API GraciaDrawCalls gracia_splats_renderer_render(
  GraciaRenderer renderer,
  const GraciaSplatsObject* splatsObjects,
  uint32_t splatsObjectsCount,
  const float* const* projections,
  const float* const* viewTransforms,
  const float* locomotionTransform,
  uint32_t targetWidth,
  uint32_t targetHeight,
  bool vr,
  const GraciaRendererSplatsPass* splatsPass,
  const GraciaRendererMotionPass* motionPass,
  const GraciaRendererMeshPass* meshPass,
  GraciaCommandBuffer commandBuffer
);

/* Turns a named feature of the renderer on or off. */
PUBLIC_API void gracia_splats_renderer_set_flag(GraciaRenderer renderer, const char* key, bool value);
/* Sets a named float parameter of the renderer. */
PUBLIC_API void gracia_splats_renderer_set_float(GraciaRenderer renderer, const char* key, float value);
/* Requests a pick at normalized device coordinates (x and y in [-1, 1]). The next
   render finds the result. Read it with read_pick_result. */
PUBLIC_API void gracia_splats_renderer_set_pick_ndc(GraciaRenderer renderer, float ndcX, float ndcY);
/* Returns the result of the last pick: the index of the object that the pick hit
   (its position in the splatsObjects array), or -1 if the pick hit nothing. Writes
   the depth of the hit into `outDepth` when `outDepth` is not NULL. */
PUBLIC_API int gracia_splats_renderer_read_pick_result(GraciaRenderer renderer, float* outDepth);
/* Returns the number of splats that the SDK drew in the last frame, when the
   visible-count readback is on; returns 0 if it is off. */
PUBLIC_API uint32_t gracia_splats_renderer_read_visible_splats_count(GraciaRenderer renderer);

/* ============================================================================
   Depth-data resolver
   ============================================================================ */

/* Resolve draw calls for each layer. The caller executes them into its own color
   and depth attachments. */
typedef struct GraciaDepthResolveDrawCalls {
  GraciaPassDrawCalls color;  /* the SDK writes project(R/G) as a color value */
  GraciaPassDrawCalls depth;  /* the SDK writes project(R/G) as a device depth value */
} GraciaDepthResolveDrawCalls;

/* The depth-data resolver changes the RG32F splat depth buffer (R = sum a*viewZ,
   G = sum a) into a projected device depth. It writes the result as a color value,
   as a device depth value, or as both. One resolver serves both eyes of a multiview or
   a multilayer depth pass. A multipass depth pass takes one resolver for each eye. */
PUBLIC_API GraciaDepthResolver gracia_depth_resolver_create(GraciaContext context);
PUBLIC_API void gracia_depth_resolver_destroy(GraciaDepthResolver resolver);

/* Renders the splats depth pass into the internal intermediate texture (the SDK
   resizes it when necessary), and records the resolve draw calls. Pass the stereoMode
   of the depth pass (from GraciaPassDrawCalls), and its views:
   - multiview or multilayer: each view of the depth pass, in one call;
   - GRACIA_STEREO_MODE_MULTIPASS: the one view of an eye, in a call of the resolver of
     that eye. A call with more than one view records nothing and gives no draw call.
   There is one projection for each layer, and it holds the reverse-Z direction.
   `linearizeColor` maps the color output in a linear way across the near and the far
   of the projection (use a projection that fits the subject, to spread the scene),
   and not as the raw device depth. */
PUBLIC_API GraciaDepthResolveDrawCalls gracia_depth_resolver_render(
  GraciaDepthResolver resolver,
  const GraciaDrawCall* depthDrawCalls, uint32_t depthViewCount, GraciaStereoMode stereoMode,
  uint32_t width, uint32_t height,
  const float* const* projections,
  GraciaColorFormat colorFormat, GraciaDepthFormat depthFormat, bool linearizeColor,
  GraciaCommandBuffer commandBuffer);

/* ============================================================================
   Draw-call replay
   ============================================================================ */

/* Replays a recorded draw-call handle into the active render pass or encoder of the
   caller. Call it one time for each view handle from a render or a resolve, in an
   open pass of the correct type. It is safe with a NULL handle (it does nothing).
   A draw call compiles its GPU pipeline for this render pass when it executes the
   first time, and it draws nothing until the pipeline is compiled. */
PUBLIC_API void gracia_draw_call_execute(GraciaDrawCall drawCall, GraciaRenderPass renderPass);
/* Releases a draw-call handle. The caller must destroy each handle that the SDK
   returns (from render or resolve) one time, after it executes the handle. */
PUBLIC_API void gracia_draw_call_destroy(GraciaDrawCall drawCall);

/* ============================================================================
   Camera and VR placement (CPU only, no GPU and no context necessary)
   ============================================================================ */

/* Movement keys for gracia_camera_set_keys, combined as a bitmask. */
typedef enum GraciaCameraKey {
  GRACIA_CAMERA_KEY_W     = 1 << 0,
  GRACIA_CAMERA_KEY_A     = 1 << 1,
  GRACIA_CAMERA_KEY_S     = 1 << 2,
  GRACIA_CAMERA_KEY_D     = 1 << 3,
  GRACIA_CAMERA_KEY_R     = 1 << 4,
  GRACIA_CAMERA_KEY_F     = 1 << 5,
  GRACIA_CAMERA_KEY_Q     = 1 << 6,
  GRACIA_CAMERA_KEY_E     = 1 << 7,
  GRACIA_CAMERA_KEY_SHIFT = 1 << 8,
} GraciaCameraKey;

/* Lens and clip-space setup of a camera:
     fov        - vertical field of view in degrees (0 keeps current, default 60)
     aspect     - viewport width divided by height (0 keeps current, default 1)
     viewHeight - viewport height in pixels or points (0 keeps current, default 1)
     reverseZ   - true for reverse-Z depth (near at 1, far at 0)
     flipY      - true for Vulkan clip space (Y down), false for Metal (Y up) */
typedef struct GraciaCameraConfig {
  float fov;
  float aspect;
  float viewHeight;
  bool reverseZ;
  bool flipY;
} GraciaCameraConfig;

/* Scene bounds and pivot for gracia_camera_frame:
     bounds   - full world-space bounds (all zero un-frames the camera)
     adaptive - optional tight bounds for view fit and speed (all zero uses bounds)
     pivot    - world-space orbit pivot (used when hasPivot is true)
     hasPivot - true to frame and orbit about pivot instead of the subject centre
     keepPose - true to update speed and depth range and keep a placed pose */
typedef struct GraciaCameraScene {
  GraciaBBox bounds;
  GraciaBBox adaptive;
  float pivot[3];
  bool hasPivot;
  bool keepPose;
} GraciaCameraScene;

/* Additive per-event input impulses for gracia_camera_input:
     rotate        - pointer drag delta in pixels or points {dx, dy}
     pan           - pan drag delta in pixels or points {dx, dy}
     zoom          - additive log-zoom (positive moves closer)
     scroll        - wheel or trackpad deltaY
     scrollPrecise - true for trackpad deltas, false for wheel notches */
typedef struct GraciaCameraDelta {
  float rotate[2];
  float pan[2];
  float zoom;
  float scroll;
  bool scrollPrecise;
} GraciaCameraDelta;

/* Camera matrices, pose, and clip planes from gracia_camera_view. Each matrix is a
   column-major 4x4 float[16]. `subjectProjection` has near and far tight to the
   subject, for linearized depth output. */
typedef struct GraciaCameraView {
  float projection[16];
  float cameraToWorld[16];
  float subjectProjection[16];
  GraciaPose pose;
  float nearPlane;
  float farPlane;
  bool framed;
} GraciaCameraView;

/* Creates a trackball orbit and fly camera with inertia. Pass NULL for defaults. */
PUBLIC_API GraciaCamera gracia_camera_create(const GraciaCameraConfig* config);
/* Destroys a camera. */
PUBLIC_API void gracia_camera_destroy(GraciaCamera camera);
/* Returns the current lens and clip-space config of a camera. */
PUBLIC_API GraciaCameraConfig gracia_camera_config(GraciaCamera camera);
/* Updates the lens and clip-space config of a camera. Zero scalar fields keep
   their current values. */
PUBLIC_API void gracia_camera_set_config(GraciaCamera camera, GraciaCameraConfig config);
/* Frames the camera on `scene` (see GraciaCameraScene). */
PUBLIC_API void gracia_camera_frame(GraciaCamera camera, GraciaCameraScene scene);
/* Puts the camera at `pose` (camera-to-world; roll survives reset). */
PUBLIC_API void gracia_camera_place(GraciaCamera camera, GraciaPose pose);
/* Moves the orbit pivot by the 4x4 portal follow transform from the last frame. */
PUBLIC_API void gracia_camera_follow(GraciaCamera camera, const float move[16]);
/* Restores the last framed or placed pose and marks the camera as framed. */
PUBLIC_API void gracia_camera_reset(GraciaCamera camera);
/* Adds pointer, pan, zoom, or scroll impulses to the camera. */
PUBLIC_API void gracia_camera_input(GraciaCamera camera, GraciaCameraDelta delta);
/* Sets the held movement keys (bitmask of GraciaCameraKey). */
PUBLIC_API void gracia_camera_set_keys(GraciaCamera camera, uint32_t keyMask);
/* Advances movement and inertia by `dt` seconds. Returns true if the pose moved. */
PUBLIC_API bool gracia_camera_update(GraciaCamera camera, float dt);
/* Updates `aspect` and `viewHeight` when greater than 0, then returns the full
   camera view, pose, and clip planes. */
PUBLIC_API GraciaCameraView gracia_camera_view(
  GraciaCamera camera, float aspect, float viewHeight);
/* Writes into `out` a column-major 4x4 model matrix that places content at full
   size so its VR `viewpoint` aligns with `head` (column-major 4x4 camera-to-world,
   or NULL for identity), upright, in the heading of `head`. */
PUBLIC_API void gracia_vr_placement(
  GraciaPose viewpoint, const float head[16], float out[16]);

#ifdef __cplusplus
}
#endif
