#pragma once

#include <filesystem>
#include <memory>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "SDK.h"

// These are C++ RAII wrappers over the C API in SDK.h. Each class holds its opaque
// handle in a unique_ptr, and calls the correct gracia_*_destroy function when it
// goes out of scope. Thus you do not free the handle yourself. See SDK.h for the
// full details of each call, the parameter units, and the env-SH and color-grade
// examples.

namespace gracia {

namespace detail {
// This deleter for the unique_ptr calls the C destroy function Fn on a handle that
// is not NULL. It makes ownership move-only, thus Fn runs one time for the handle.
template<auto Fn>
struct CDeleter { void operator()(void* p) const { if (p) Fn(p); } };

template<auto Fn>
using Handle = std::unique_ptr<void, CDeleter<Fn>>;
}  // namespace detail

// This class holds one recorded draw-call handle. It calls gracia_draw_call_destroy
// when it goes out of scope. execute() replays the handle into the active render
// pass of the caller. A default DrawCall, or a DrawCall that you moved from, does
// nothing.
class DrawCall {
 public:
  explicit DrawCall(void* ptr) : h_(ptr) {}
  void* get() const { return h_.get(); }
  void execute(GraciaRenderPass renderPass) {
    if (h_) gracia_draw_call_execute(h_.get(), renderPass);
  }

 private:
  detail::Handle<gracia_draw_call_destroy> h_;
};

// The draw calls of one pass, with one optional DrawCall for each view. The SDK sets
// `stereo` only when the pass is truly stereo (multiview, or a mode that is not
// multipass). nullopt means mono.
struct PassDrawCalls {
  std::vector<std::optional<DrawCall>> views;
  std::optional<GraciaStereoMode> stereo;
};

// The four passes that SdkSplatsRenderer::render makes. `buffering` is true when a
// video frame was not ready. Then do not present the frame, and do the render again.
// `compiling` is true while the GPU pipelines of the objects compile. This structure
// is the same as GraciaDrawCalls.
struct DrawCalls {
  PassDrawCalls color;
  PassDrawCalls depth;
  PassDrawCalls motion;
  PassDrawCalls mesh;
  bool buffering = false;
  bool compiling = false;
};

class StaticSplats;
class VideoStream;

// A GPU session (gracia_context_create and gracia_context_destroy). Make one session
// for each device. You make every other object from this session, and you must
// destroy them before the session. Use the bool operator to test for success.
class Context {
 public:
  Context(const GraciaContextDescriptor& desc,
          const std::filesystem::path& cacheDir = {})
    : h_(gracia_context_create(&desc, cacheDir.empty() ? nullptr : cacheDir.c_str())) {}

  void* get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }
  uint64_t gpuAllocatedBytes() const {
    return h_ ? gracia_context_gpu_allocated_bytes(h_.get()) : 0;
  }

 private:
  detail::Handle<gracia_context_destroy> h_;
};

// The splats renderer (gracia_splats_renderer_*). It records the draw calls of each
// frame, and the caller replays them into its own attachments.
class SdkSplatsRenderer {
 public:
  // Makes a renderer for a maximum of `maxSplatsCount` visible splats in one frame.
  // Set `vr` to true for two-eye output. A mono renderer cannot render stereo later.
  static SdkSplatsRenderer create(
    const Context* ctx,
    uint32_t maxSplatsCount,
    bool vr = false
  ) {
    return SdkSplatsRenderer(
      gracia_splats_renderer_create(ctx->get(), maxSplatsCount, vr));
  }

  SdkSplatsRenderer() = default;

  void* get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }

  // Apple only. Gives the tile settings for this splats pass. Use them in the
  // MTLRenderPass that executes the draw calls. (gracia_splats_renderer_metal_tile_settings)
  GraciaMetalTileSettings metalTileSettingsValue(
    const GraciaRendererSplatsPass& splatsPass
  ) const {
    if (!h_) return {};
    return gracia_splats_renderer_metal_tile_settings(h_.get(), &splatsPass);
  }

  // Records a frame. `splats` takes a StaticSplats* or a VideoStream* in a variant.
  // `projections` and `viewTransforms` are column-major 4x4 pointers, one for each
  // eye (see SDK.h). Pass nullptr for motionPass or meshPass to skip that pass. The
  // DrawCalls result holds its handles and frees them when it goes out of scope.
  // Check .buffering before you present.
  DrawCalls render(
    const std::vector<std::variant<StaticSplats*, VideoStream*>>& splats,
    float** projections, float** viewTransforms,
    float* locomotionTransform,
    uint32_t targetWidth, uint32_t targetHeight,
    bool vr,
    const GraciaRendererSplatsPass& splatsPass,
    const GraciaRendererMotionPass* motionPass,
    const GraciaRendererMeshPass* meshPass,
    GraciaCommandBuffer commandBuffer
  );

  // Turns a named feature of the renderer on or off.
  void setFlag(const char* key, bool value) {
    if (h_) gracia_splats_renderer_set_flag(h_.get(), key, value);
  }
  // Sets a named float parameter of the renderer.
  void setFloat(const char* key, float value) {
    if (h_) gracia_splats_renderer_set_float(h_.get(), key, value);
  }

  // Requests a pick at normalized device coordinates (x and y in [-1, 1]). The next
  // render() finds the result.
  void setPickNDC(float ndcX, float ndcY) {
    if (h_) gracia_splats_renderer_set_pick_ndc(h_.get(), ndcX, ndcY);
  }

  // Returns the result of the last pick: the index of the object that the pick hit
  // (its position in the render() list), or -1 if the pick hit nothing. Writes the
  // depth of the hit into `outDepth` when you supply it.
  int readPickResult(float* outDepth = nullptr) {
    if (!h_) { if (outDepth) *outDepth = 0; return -1; }
    return gracia_splats_renderer_read_pick_result(h_.get(), outDepth);
  }

  // Returns the number of splats that the SDK drew in the last frame, when the
  // visible-count readback is on; returns 0 if it is off.
  uint32_t readVisibleSplatsCount() const {
    return h_ ? gracia_splats_renderer_read_visible_splats_count(h_.get()) : 0;
  }

 private:
  explicit SdkSplatsRenderer(void* p) : h_(p) {}
  detail::Handle<gracia_splats_renderer_destroy> h_;
};

struct DepthResolveDrawCalls {
  PassDrawCalls color;  // rendered like the splats color pass
  PassDrawCalls depth;  // rendered like the splats depth pass
};

// The depth-data resolver (gracia_depth_resolver_*). It projects the RG32F splat
// depth buffer into a device depth value, a color value, or both. One resolver is
// correct for any stereo mode.
class SdkDepthResolver {
 public:
  static SdkDepthResolver create(const Context* ctx) {
    return SdkDepthResolver(gracia_depth_resolver_create(ctx->get()));
  }

  SdkDepthResolver() = default;

  void* get() const { return h_.get(); }
  explicit operator bool() const { return h_ != nullptr; }

  // Resolves the depth pass, and returns the draw calls in the stereoMode of the
  // depth pass. A GRACIA_*_FORMAT_UNDEFINED value skips that output.
  DepthResolveDrawCalls render(
    const std::vector<DrawCall*>& depthViews, GraciaStereoMode stereoMode,
    uint32_t width, uint32_t height,
    const std::vector<const float*>& projections,
    GraciaColorFormat colorFormat, GraciaDepthFormat depthFormat, bool linearizeColor,
    GraciaCommandBuffer commandBuffer
  ) {
    DepthResolveDrawCalls result;
    if (!h_) return result;
    std::vector<void*> views;
    views.reserve(depthViews.size());
    for (auto* d : depthViews) views.push_back(d ? d->get() : nullptr);
    auto raw = gracia_depth_resolver_render(
      h_.get(), views.data(), uint32_t(views.size()), stereoMode,
      width, height, projections.data(),
      colorFormat, depthFormat, linearizeColor, commandBuffer);
    const auto fillPass = [](PassDrawCalls& out, const GraciaPassDrawCalls& in) {
      out.stereo = (in.viewCount > 1 || in.stereoMode != GRACIA_STEREO_MODE_MULTIPASS)
        ? std::optional(in.stereoMode) : std::nullopt;
      out.views.resize(in.viewCount);
      for (uint32_t v = 0; v < in.viewCount; v++)
        if (in.views[v]) out.views[v].emplace(in.views[v]);
    };
    fillPass(result.color, raw.color);
    fillPass(result.depth, raw.depth);
    return result;
  }

 private:
  explicit SdkDepthResolver(void* p) : h_(p) {}
  detail::Handle<gracia_depth_resolver_destroy> h_;
};

// A static one-frame asset (gracia_static_splats_*). `contentType` must be PLY, GUF,
// or SOG. Check that get() is not nullptr for a successful load.
class StaticSplats {
 public:
  StaticSplats(
    const Context* context, const char* headerData,
    const std::filesystem::path& filePath,
    GraciaContentType contentType
  ) : h_(gracia_static_splats_create(
        context->get(), headerData, filePath.c_str(), contentType)) {}

  void* get() const { return h_.get(); }
  uint32_t count() const    { return h_ ? gracia_static_splats_count(h_.get()) : 0; }
  GraciaBBox bbox() const   { return h_ ? gracia_static_splats_bbox(h_.get()) : GraciaBBox {}; }
  // A bounds that ignores distant splats (the 10th to 90th percentile). It is better
  // to frame a camera automatically.
  GraciaBBox adaptiveBBox() const {
    return h_ ? gracia_static_splats_adaptive_bbox(h_.get()) : GraciaBBox {};
  }
  // A column-major 4x4 float[16], from local to world.
  void setTransform(float* t) { if (h_) gracia_static_splats_set_transform(h_.get(), t); }
  // A 4x4 SH environment probe (16 floats); nullptr turns it off. See set_env_sh in
  // SDK.h for the layout.
  void setEnvSH(const float* sh4x4) { if (h_) gracia_static_splats_set_env_sh(h_.get(), sh4x4); }
  // An HSV grade: hue (a turn), saturation and value (multipliers), and weight (a mix
  // in [0,1]).
  void setColorGrade(float hue, float saturation, float value, float weight) {
    if (h_) gracia_static_splats_set_color_grade(h_.get(), hue, saturation, value, weight);
  }
  // Turns a named feature of the object on or off.
  void setFlag(const char* key, bool value) { if (h_) gracia_static_splats_set_flag(h_.get(), key, value); }
  // The opacity multiplier of the whole object, in [0,1].
  void setVisibility(float v) { if (h_) gracia_static_splats_set_visibility(h_.get(), v); }
  // Crops to a smaller box. The min and max values are normalized on each axis, in
  // [-1,1], against bbox(). `falloff` is the width of the soft edge, in [0,1].
  void setBboxMask(
    float minX, float minY, float minZ,
    float maxX, float maxY, float maxZ, float falloff) {
    if (h_) gracia_static_splats_set_bbox_mask(
      h_.get(), minX, minY, minZ, maxX, maxY, maxZ, falloff);
  }
  void clearBboxMask() {
    if (h_) gracia_static_splats_clear_bbox_mask(h_.get());
  }

 private:
  detail::Handle<gracia_static_splats_destroy> h_;
};

// A metadata-only MINT probe (gracia_video_desc_*): bounds, duration, and audio,
// without a GPU decode. It uses less time and memory than a VideoStream when you
// need only the metadata.
class VideoDesc {
 public:
  VideoDesc(const char* head, const std::filesystem::path& path)
    : h_(gracia_video_desc_create(head, path.c_str())) {}

  void* get() const { return h_.get(); }
  GraciaBBox bbox() const     { return h_ ? gracia_video_desc_bbox(h_.get()) : GraciaBBox {}; }
  GraciaBBox adaptiveBBox() const {
    return h_ ? gracia_video_desc_adaptive_bbox(h_.get()) : GraciaBBox {};
  }
  double duration() const     { return h_ ? gracia_video_desc_duration(h_.get()) : 0.0; }
  uint32_t audioSize() const  { return h_ ? gracia_video_desc_audio_size(h_.get()) : 0; }
  // Copies the audio into `buf`. Allocate audioSize() bytes first. Returns false if
  // there is none.
  bool audioRead(char* buf) const { return h_ && gracia_video_desc_audio_read(h_.get(), buf); }

 private:
  detail::Handle<gracia_video_desc_destroy> h_;
};

// A MINT video for playback (gracia_video_stream_*). Move the playhead with
// setTime(). Call ready() before you render. Then draw the video with
// SdkSplatsRenderer::render.
class VideoStream {
 public:
  // From a local file. `head` is an optional split-asset header (nullptr for one
  // file). Set `needMesh` to true to also decode the proxy mesh stream.
  VideoStream(
    const Context* context, const char* head,
    const std::filesystem::path& path, bool needMesh = false
  ) : h_(gracia_video_stream_create(context->get(), head, path.c_str(), needMesh)) {}

  // From an https:// URL, with an optional access token.
  VideoStream(
    const Context* context, const char* url, const char* token = nullptr
  ) : h_(gracia_video_stream_create_from_url(context->get(), url, token)) {}

  void* get() const { return h_.get(); }
  GraciaBBox bbox() const     { return h_ ? gracia_video_stream_bbox(h_.get()) : GraciaBBox {}; }
  GraciaBBox adaptiveBBox() const {
    return h_ ? gracia_video_stream_adaptive_bbox(h_.get()) : GraciaBBox {};
  }
  // Runs the decoder one step. Returns true when the SDK decoded the frame and can
  // render it.
  bool ready() const          { return h_ && gracia_video_stream_ready(h_.get()); }
  // The maximum number of splats in one frame. Use it to set the renderer budget.
  uint64_t maxSplatsCount() const {
    return h_ ? gracia_video_stream_max_splats_count(h_.get()) : 0;
  }
  // The splats of the frame acquired. This changes with the frame.
  uint32_t splatsCount() const {
    return h_ ? gracia_video_stream_splats_count(h_.get()) : 0;
  }
  double duration() const     { return h_ ? gracia_video_stream_duration(h_.get()) : 0.0; }
  uint32_t audioSize() const  { return h_ ? gracia_video_stream_audio_size(h_.get()) : 0; }
  bool audioRead(char* buf) const { return h_ && gracia_video_stream_audio_read(h_.get(), buf); }

  // Moves the playhead to `t` seconds. The next ready() or render decodes that frame.
  void setTime(double t)        { if (h_) gracia_video_stream_set_time(h_.get(), t); }
  void setPlaybackStart(double t) { if (h_) gracia_video_stream_set_playback_start(h_.get(), t); }
  void setPlaybackEnd(double t)   { if (h_) gracia_video_stream_set_playback_end(h_.get(), t); }
  void setTransform(float* t)   { if (h_) gracia_video_stream_set_transform(h_.get(), t); }
  // The same as StaticSplats::setEnvSH and setColorGrade (see SDK.h for the units and
  // the examples).
  void setEnvSH(const float* sh4x4) { if (h_) gracia_video_stream_set_env_sh(h_.get(), sh4x4); }
  void setColorGrade(float hue, float saturation, float value, float weight) {
    if (h_) gracia_video_stream_set_color_grade(h_.get(), hue, saturation, value, weight);
  }
  void setFlag(const char* key, bool value) { if (h_) gracia_video_stream_set_flag(h_.get(), key, value); }
  void setVisibility(float v) { if (h_) gracia_video_stream_set_visibility(h_.get(), v); }
  // Crops to a smaller box; see StaticSplats::setBboxMask for the coordinate system.
  void setBboxMask(
    float minX, float minY, float minZ,
    float maxX, float maxY, float maxZ, float falloff) {
    if (h_) gracia_video_stream_set_bbox_mask(
      h_.get(), minX, minY, minZ, maxX, maxY, maxZ, falloff);
  }
  void clearBboxMask() {
    if (h_) gracia_video_stream_clear_bbox_mask(h_.get());
  }

 private:
  detail::Handle<gracia_video_stream_destroy> h_;
};

// The handles that a splats list passes to the C entry points.
inline std::vector<GraciaSplatsObject> splatsObjectHandles(
  const std::vector<std::variant<StaticSplats*, VideoStream*>>& splats
) {
  std::vector<GraciaSplatsObject> objs;
  objs.reserve(splats.size());
  for (const auto& s : splats) {
    std::visit([&](auto* p) {
      bool isVideo = std::is_same_v<std::decay_t<decltype(*p)>, VideoStream>;
      objs.push_back({p->get(), isVideo});
    }, s);
  }
  return objs;
}

inline DrawCalls SdkSplatsRenderer::render(
  const std::vector<std::variant<StaticSplats*, VideoStream*>>& splats,
  float** projections, float** viewTransforms,
  float* locomotionTransform,
  uint32_t targetWidth, uint32_t targetHeight,
  bool vr,
  const GraciaRendererSplatsPass& splatsPass,
  const GraciaRendererMotionPass* motionPass,
  const GraciaRendererMeshPass* meshPass,
  GraciaCommandBuffer commandBuffer
) {
  if (!h_ || splats.empty()) return {};

  auto objs = splatsObjectHandles(splats);

  auto raw = gracia_splats_renderer_render(
    h_.get(), objs.data(), uint32_t(objs.size()),
    projections, viewTransforms, locomotionTransform,
    targetWidth, targetHeight, vr,
    &splatsPass, motionPass, meshPass,
    commandBuffer
  );

  DrawCalls result;
  result.buffering = raw.buffering;
  result.compiling = raw.compiling;

  const auto fillPass = [](PassDrawCalls& out, const GraciaPassDrawCalls& in) {
    out.stereo = (in.viewCount > 1 || in.stereoMode != GRACIA_STEREO_MODE_MULTIPASS)
      ? std::optional(in.stereoMode) : std::nullopt;
    out.views.resize(in.viewCount);
    for (uint32_t v = 0; v < in.viewCount; v++)
      if (in.views[v]) out.views[v].emplace(in.views[v]);
  };
  fillPass(result.color, raw.color);
  fillPass(result.depth, raw.depth);
  fillPass(result.motion, raw.motion);
  fillPass(result.mesh, raw.mesh);
  return result;
}

// Returns the MINT content version from a file on disk (0 if the file is not a valid
// MINT).
inline uint32_t videoMintVersionFromFile(const std::filesystem::path& path) {
  return gracia_video_mint_version_from_file(path.c_str());
}

// Returns the MINT content version from a header string (0 if the SDK cannot parse
// it).
inline uint32_t videoMintVersionFromHead(const std::string& head) {
  return gracia_video_mint_version_from_head(head.c_str());
}

}  // namespace gracia
